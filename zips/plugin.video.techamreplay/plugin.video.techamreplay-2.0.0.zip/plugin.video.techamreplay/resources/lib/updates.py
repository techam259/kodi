"""Controllo leggero della versione pubblicata nel repository TECHAM."""

import re
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui

from api import claim_available_update_notice, log, record_update_status


ADDON = xbmcaddon.Addon()
ADDON_ID = "plugin.video.techamreplay"
INDEX_URL = "https://raw.githubusercontent.com/techam259/kodi/main/addons.xml"


def version_key(value):
    parts = [int(part) for part in re.findall(r"\d+", str(value or ""))]
    return tuple((parts + [0, 0, 0])[:3])


def fetch_available_version():
    request = urllib.request.Request(
        INDEX_URL,
        headers={"User-Agent": "TECHAM-Replay-Kodi-Version-Check"},
        method="GET",
    )
    with urllib.request.urlopen(request, timeout=8) as response:
        root = ET.fromstring(response.read())
    for addon in root.findall("addon"):
        if addon.get("id") == ADDON_ID:
            return str(addon.get("version") or "").strip()
    return ""


def check_for_updates(notify=True):
    current = ADDON.getAddonInfo("version")
    try:
        available = fetch_available_version()
        if not available:
            raise ValueError("Versione non presente nell'indice")
        update_available = version_key(available) > version_key(current)
        record_update_status(available, update_available, "")
        if (
            notify
            and update_available
            and ADDON.getSettingBool("notify_updates")
            and claim_available_update_notice(available)
        ):
            xbmcgui.Dialog().notification(
                "TECHAM Replay Sync",
                "Aggiornamento {0} disponibile.".format(available),
                time=9000,
            )
        return True, {
            "current": current,
            "available": available,
            "updateAvailable": update_available,
        }
    except (urllib.error.URLError, OSError, ValueError, ET.ParseError) as error:
        message = "Controllo non riuscito"
        record_update_status("", False, message)
        log("Controllo versione fallito: {0}".format(type(error).__name__), xbmc.LOGWARNING)
        return False, {"current": current, "available": "", "error": message}


def refresh_repository():
    try:
        xbmc.executebuiltin("UpdateAddonRepos")
        log("Controllo aggiornamenti repository richiesto.")
        return True
    except Exception as error:
        log(
            "Controllo aggiornamenti repository fallito: {0}".format(
                type(error).__name__
            ),
            xbmc.LOGWARNING,
        )
        return False
