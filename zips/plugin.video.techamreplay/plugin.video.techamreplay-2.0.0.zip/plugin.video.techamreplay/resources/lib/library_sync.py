"""Allinea Replay e Kodi con paginazione, diagnosi e associazioni manuali."""

import json
import os
from datetime import datetime, timezone

import xbmcaddon
import xbmcgui
import xbmcvfs

from api import claim_content_notices, get_remote_library_snapshot, log, record_library_sync
from kodi_rpc import json_rpc
from mappings import get_mapping, save_mapping
from playback import non_negative_int, positive_int


ADDON = xbmcaddon.Addon()
STATE_FILE = "library-sync-state.json"
UNMATCHED_FILE = "library-unmatched.json"
JOURNAL_FILE = "sync-journal.json"
PAGE_SIZE = 500
JOURNAL_LIMIT = 50


def _profile_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return profile


def _file_path(name):
    return os.path.join(_profile_path(), name)


def _read_json(name, fallback):
    try:
        with open(_file_path(name), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data
    except (OSError, TypeError, ValueError):
        return fallback


def _write_json(name, data):
    path = _file_path(name)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
    os.replace(temporary, path)


def _read_state():
    data = _read_json(STATE_FILE, {})
    managed = data.get("managed", []) if isinstance(data, dict) else []
    return set(value for value in managed if isinstance(value, str))


def _write_state(managed):
    try:
        _write_json(STATE_FILE, {"managed": sorted(managed)})
    except OSError as error:
        log("Stato libreria non salvato: {0}".format(error))


def _write_unmatched(items):
    try:
        _write_json(UNMATCHED_FILE, items[-500:])
    except OSError as error:
        log("Elementi non associati non salvati: {0}".format(error))


def get_unmatched_items():
    data = _read_json(UNMATCHED_FILE, [])
    return data if isinstance(data, list) else []


def save_manual_mapping(item, tmdb_id):
    if not isinstance(item, dict):
        raise ValueError("Elemento non valido")
    return save_mapping(item.get("kind"), item.get("kodiId"), tmdb_id)


def record_journal(success, stats):
    history = _read_json(JOURNAL_FILE, [])
    if not isinstance(history, list):
        history = []
    values = stats if isinstance(stats, dict) else {}
    history.append({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "success": bool(success),
        "stats": values,
    })
    try:
        _write_json(JOURNAL_FILE, history[-JOURNAL_LIMIT:])
    except OSError as error:
        log("Cronologia sincronizzazione non salvata: {0}".format(error))


def get_sync_history():
    data = _read_json(JOURNAL_FILE, [])
    return list(reversed(data[-JOURNAL_LIMIT:])) if isinstance(data, list) else []


def _movie_key(tmdb_id):
    return "movie:{0}".format(tmdb_id)


def _episode_key(tmdb_id, season, episode):
    return "episode:{0}:{1}:{2}".format(tmdb_id, season, episode)


def _remote_keys(snapshot):
    if not isinstance(snapshot.get("completedMovies"), list) or not isinstance(snapshot.get("watchedEpisodes"), list):
        raise ValueError("Liste di sincronizzazione mancanti")
    remote = set()
    for item in snapshot.get("completedMovies", []):
        if isinstance(item, dict) and positive_int(item.get("tmdbId")):
            remote.add(_movie_key(positive_int(item.get("tmdbId"))))
    for item in snapshot.get("watchedEpisodes", []):
        if not isinstance(item, dict):
            continue
        tmdb_id = positive_int(item.get("tmdbId"))
        season = non_negative_int(item.get("season"))
        episode = positive_int(item.get("episode"))
        if tmdb_id and season is not None and episode:
            remote.add(_episode_key(tmdb_id, season, episode))
    return remote


def _paged(rpc, method, properties, result_key):
    collected = []
    start = 0
    while True:
        result = rpc(method, {
            "properties": properties,
            "limits": {"start": start, "end": start + PAGE_SIZE},
        })
        if not isinstance(result, dict):
            raise ValueError("Risposta Kodi non disponibile: {0}".format(method))
        page = result.get(result_key, [])
        if not isinstance(page, list):
            raise ValueError("Risposta Kodi non valida: {0}".format(method))
        collected.extend(page)
        limits = result.get("limits")
        if not isinstance(limits, dict):
            break
        end = int(limits.get("end", start + len(page)) or 0)
        total = int(limits.get("total", len(collected)) or 0)
        if end >= total or not page:
            break
        start = end
    return collected


def _scan_local(rpc):
    items = {}
    unmatched = []
    movies = _paged(rpc, "VideoLibrary.GetMovies", ["uniqueid", "playcount", "title"], "movies")
    for movie in movies:
        movie_id = positive_int(movie.get("movieid"))
        tmdb_id = positive_int((movie.get("uniqueid") or {}).get("tmdb"))
        if not tmdb_id and movie_id:
            tmdb_id = get_mapping("movie", movie_id)
        if tmdb_id and movie_id:
            items[_movie_key(tmdb_id)] = {
                "kind": "movie", "id": movie_id, "playcount": int(movie.get("playcount", 0) or 0),
                "title": str(movie.get("title") or "Film"), "tmdbId": tmdb_id,
            }
        elif movie_id:
            unmatched.append({"kind": "movie", "kodiId": movie_id, "title": str(movie.get("title") or "Film")})

    show_map = {}
    shows = _paged(rpc, "VideoLibrary.GetTVShows", ["uniqueid", "title"], "tvshows")
    for show in shows:
        show_id = positive_int(show.get("tvshowid"))
        tmdb_id = positive_int((show.get("uniqueid") or {}).get("tmdb"))
        if not tmdb_id and show_id:
            tmdb_id = get_mapping("tvshow", show_id)
        if show_id and tmdb_id:
            show_map[show_id] = (tmdb_id, str(show.get("title") or "Serie TV"))
        elif show_id:
            unmatched.append({"kind": "tvshow", "kodiId": show_id, "title": str(show.get("title") or "Serie TV")})

    episodes = _paged(rpc, "VideoLibrary.GetEpisodes", ["tvshowid", "season", "episode", "playcount", "title"], "episodes")
    for item in episodes:
        show_id = positive_int(item.get("tvshowid"))
        show_info = show_map.get(show_id)
        season = non_negative_int(item.get("season"))
        episode = positive_int(item.get("episode"))
        episode_id = positive_int(item.get("episodeid"))
        if show_info and season is not None and episode and episode_id:
            tmdb_id, show_title = show_info
            items[_episode_key(tmdb_id, season, episode)] = {
                "kind": "episode", "id": episode_id, "playcount": int(item.get("playcount", 0) or 0),
                "title": show_title, "tmdbId": tmdb_id, "season": season, "episode": episode,
            }
    _write_unmatched(unmatched)
    return items, unmatched


def _local_items(rpc):
    return _scan_local(rpc)[0]


def apply_snapshot(snapshot, rpc=json_rpc):
    if not isinstance(snapshot, dict):
        raise ValueError("Snapshot Replay non valido")
    remote = _remote_keys(snapshot)
    previous = _read_state()
    local, unmatched = _scan_local(rpc)
    managed = set()
    changed = watched = unwatched = failures = 0
    for key, item in local.items():
        desired = 1 if key in remote else (0 if key in previous else None)
        if desired is None:
            continue
        current = 1 if item["playcount"] > 0 else 0
        success = current == desired
        if not success:
            method = "VideoLibrary.SetMovieDetails" if item["kind"] == "movie" else "VideoLibrary.SetEpisodeDetails"
            identifier = "movieid" if item["kind"] == "movie" else "episodeid"
            success = rpc(method, {identifier: item["id"], "playcount": desired}) == "OK"
            if success:
                changed += 1
                watched += int(bool(desired))
                unwatched += int(not desired)
            else:
                failures += 1
        if desired or not success:
            managed.add(key)
    _write_state(managed)
    return {
        "changed": changed, "watched": watched, "unwatched": unwatched,
        "scanned": len(local), "managed": len(managed), "unmatched": len(unmatched),
        "missingRemote": len(remote.difference(local.keys())), "failures": failures,
    }


def find_local_item(identity, rpc=json_rpc):
    if not isinstance(identity, dict):
        return None
    tmdb_id = positive_int(identity.get("tmdbId"))
    if not tmdb_id:
        return None
    if identity.get("mediaType") == "movie":
        key = _movie_key(tmdb_id)
    else:
        season = non_negative_int(identity.get("season"))
        episode = positive_int(identity.get("episode"))
        if season is None or not episode:
            return None
        key = _episode_key(tmdb_id, season, episode)
    return _local_items(rpc).get(key)


def open_local_item(identity, rpc=json_rpc):
    item = find_local_item(identity, rpc)
    if not item:
        return False
    target = {"movieid": item["id"]} if item["kind"] == "movie" else {"episodeid": item["id"]}
    return rpc("Player.Open", {"item": target}) == "OK"


def _notify_content(notices):
    fresh = claim_content_notices(notices)
    for notice in fresh[:3]:
        title = str(notice.get("seriesTitle") or "Serie TV")
        season = int(notice.get("season", 0) or 0)
        episode = int(notice.get("episode", 0) or 0)
        heading = "Nuova stagione di {0}".format(title) if season > 0 and episode == 1 else "Nuovo episodio di {0}".format(title)
        xbmcgui.Dialog().notification("TECHAM Replay", "{0} · S{1:02d}E{2:02d}".format(heading, season, episode), time=9000)
    return len(fresh)


def sync_now(rpc=json_rpc):
    if not ADDON.getSettingBool("enabled"):
        result = {"reason": "disabled"}
        record_journal(False, result)
        return False, result
    if not ADDON.getSettingBool("library_sync_enabled"):
        result = {"reason": "library_disabled"}
        record_journal(False, result)
        return False, result
    snapshot = get_remote_library_snapshot()
    if snapshot is None:
        result = {"reason": "unavailable"}
        record_journal(False, result)
        return False, result
    try:
        stats = apply_snapshot(snapshot, rpc)
    except (OSError, TypeError, ValueError) as error:
        log("Snapshot libreria non valido: {0}".format(error))
        result = {"reason": "invalid_snapshot"}
        record_journal(False, result)
        return False, result
    record_library_sync(stats, snapshot.get("serverTime", ""))
    record_journal(stats.get("failures", 0) == 0, stats)
    if stats["changed"] and ADDON.getSettingBool("notify_sync"):
        xbmcgui.Dialog().notification("TECHAM Replay", "Libreria aggiornata: {0} elementi.".format(stats["changed"]), time=6000)
    stats["newContent"] = _notify_content(snapshot.get("newContent", [])) if ADDON.getSettingBool("notify_content") else 0
    return stats.get("failures", 0) == 0, stats
