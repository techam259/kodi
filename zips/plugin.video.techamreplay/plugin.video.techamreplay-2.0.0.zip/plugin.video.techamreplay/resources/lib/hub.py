"""Interfaccia leggera del Replay Hub dentro Kodi."""

import xbmcgui

from api import get_remote_hub
from library_sync import open_local_item


TITLE = "TECHAM Replay Hub"


def _item_label(item):
    title = str(item.get("title") or "Contenuto")
    if item.get("mediaType") == "episode":
        title += " · S{0:02d}E{1:02d}".format(int(item.get("season", 0) or 0), int(item.get("episode", 0) or 0))
    if "percentage" in item:
        title += " · {0:.0f}%".format(float(item.get("percentage", 0) or 0))
    return title


def _open_list(items, empty_message):
    values = items if isinstance(items, list) else []
    if not values:
        xbmcgui.Dialog().ok(TITLE, empty_message)
        return
    choice = xbmcgui.Dialog().select(TITLE, [_item_label(item) for item in values])
    if choice < 0:
        return
    item = values[choice]
    if item.get("mediaType") not in ("movie", "episode"):
        xbmcgui.Dialog().ok(TITLE, "La serie è nel tuo profilo Replay. Apri un episodio presente nella libreria Kodi per riprodurlo.")
        return
    if not open_local_item(item):
        xbmcgui.Dialog().ok(TITLE, "Contenuto non trovato nella libreria locale di Kodi.")


def show_hub():
    data = get_remote_hub()
    if not data:
        xbmcgui.Dialog().ok(TITLE, "Replay Hub non disponibile. Verifica connessione e collegamento.")
        return False
    sections = [
        ("Continua a guardare", data.get("continueWatching", []), "Nessun contenuto da riprendere."),
        ("La mia libreria", data.get("library", []), "La libreria Replay è vuota."),
        ("Attività recente", data.get("recentActivity", []), "Nessuna attività recente."),
    ]
    choice = xbmcgui.Dialog().select(TITLE, [item[0] for item in sections])
    if choice >= 0:
        _open_list(sections[choice][1], sections[choice][2])
    return True
