"""Piccolo adattatore JSON-RPC condiviso dal servizio e dal pannello Kodi."""

import json

import xbmc


def json_rpc(method, params=None):
    query = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        query["params"] = params
    try:
        response = xbmc.executeJSONRPC(json.dumps(query))
        parsed = json.loads(response)
        if "error" in parsed:
            return None
        return parsed.get("result")
    except (TypeError, ValueError):
        return None
