"""Associa manualmente elementi della libreria Kodi agli identificativi TMDb."""

import json
import os

import xbmcaddon
import xbmcvfs


ADDON = xbmcaddon.Addon()
FILE_NAME = "library-mappings.json"


def _path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return os.path.join(profile, FILE_NAME)


def _read():
    try:
        with open(_path(), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, TypeError, ValueError):
        return {}


def _write(data):
    path = _path()
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    os.replace(temporary, path)


def mapping_key(kind, kodi_id):
    normalized = "movie" if kind == "movie" else "tvshow"
    return "{0}:{1}".format(normalized, int(kodi_id))


def get_mapping(kind, kodi_id):
    try:
        value = int(_read().get(mapping_key(kind, kodi_id), 0))
        return value if value > 0 else None
    except (TypeError, ValueError):
        return None


def save_mapping(kind, kodi_id, tmdb_id):
    kodi_value = int(kodi_id)
    tmdb_value = int(tmdb_id)
    if kodi_value <= 0 or tmdb_value <= 0:
        raise ValueError("Identificativo non valido")
    data = _read()
    data[mapping_key(kind, kodi_value)] = tmdb_value
    _write(data)
    return tmdb_value


def remove_mapping(kind, kodi_id):
    data = _read()
    removed = data.pop(mapping_key(kind, kodi_id), None) is not None
    if removed:
        _write(data)
    return removed


def list_mappings():
    return dict(_read())
