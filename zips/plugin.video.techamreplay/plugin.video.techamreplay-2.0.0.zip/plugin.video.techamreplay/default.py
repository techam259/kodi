"""Pannello diagnostico di TECHAM Replay Sync per Kodi."""

import os
import sys
from datetime import datetime

import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))

from api import (  # noqa: E402
    connect_with_code,
    disconnect_device,
    flush_pending_progress,
    get_sync_status,
    test_connection,
)
from hub import show_hub  # noqa: E402
from library_sync import (  # noqa: E402
    get_sync_history,
    get_unmatched_items,
    save_manual_mapping,
    sync_now as sync_library_now,
)
from updates import check_for_updates, refresh_repository  # noqa: E402


VERSION = ADDON.getAddonInfo("version")
TITLE = "TECHAM Replay Sync · v{0}".format(VERSION)


def text(identifier, fallback):
    value = ADDON.getLocalizedString(identifier)
    return value or fallback


def format_timestamp(value):
    if not value:
        return text(30020, "Mai")
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed.astimezone().strftime("%d/%m/%Y %H:%M")
    except (TypeError, ValueError):
        return str(value)


def status_message(status):
    linked = text(30014, "Collegato") if status["linked"] else text(30015, "Non collegato")
    enabled = text(30016, "Attiva") if status["enabled"] else text(30017, "Disattivata")
    api_state = text(30052, "Valido") if status["apiConfigured"] else text(30053, "Non valido")
    action_labels = {
        "progress": text(30044, "Invio avanzamento"),
        "resume": text(30045, "Lettura punto di ripresa"),
        "test": text(30046, "Verifica connessione"),
        "link": text(30047, "Collegamento dispositivo"),
        "disconnect": text(30048, "Disconnessione dispositivo"),
        "device": text(30049, "Aggiornamento dispositivo"),
        "library": text(30064, "Sincronizzazione libreria"),
    }
    latest = status.get("availableVersion") or text(30020, "Mai")
    update_label = text(30067, "Aggiornamento disponibile") if status.get(
        "updateAvailable"
    ) else text(30068, "Aggiornato")
    lines = [
        "{0}: {1}".format(text(30029, "Versione"), status["version"]),
        "{0}: {1} ({2})".format(text(30066, "Ultima disponibile"), latest, update_label),
        "{0}: {1}".format(text(30026, "Dispositivo"), status["deviceName"]),
        "{0}: {1}".format(text(30078, "Profilo Kodi"), status.get("kodiProfile", "Master user")),
        "{0}: {1}".format(text(30001, "Connessione"), linked),
        "{0}: {1}".format(text(30051, "Indirizzo API"), api_state),
        "{0}: {1}".format(text(30027, "Sincronizzazione"), enabled),
        "{0}: {1}".format(text(30018, "Elementi in attesa"), status["pendingCount"]),
        "{0}: {1}".format(
            text(30019, "Ultima sincronizzazione riuscita"),
            format_timestamp(status["lastSuccessAt"]),
        ),
        "{0}: {1}".format(
            text(30030, "Ultimo tentativo"),
            format_timestamp(status["lastAttemptAt"]),
        ),
        "{0}: {1}".format(
            text(30065, "Ultimo controllo aggiornamenti"),
            format_timestamp(status.get("lastUpdateCheckAt")),
        ),
        "{0}: {1}".format(
            text(30063, "Ultima sincronizzazione libreria"),
            format_timestamp(status.get("lastLibrarySyncAt")),
        ),
    ]
    if status.get("lastLibrarySyncAt"):
        lines.append("{0}: {1} ({2} + / {3} -)".format(
            text(30069, "Ultime modifiche libreria"),
            status.get("lastLibraryChanged", 0),
            status.get("lastLibraryWatched", 0),
            status.get("lastLibraryUnwatched", 0),
        ))
        lines.append("{0}: {1}".format(
            text(30079, "Elementi da associare"), status.get("lastLibraryUnmatched", 0)
        ))
    if status.get("lastAction"):
        lines.append("{0}: {1}".format(
            text(30031, "Ultima operazione"),
            action_labels.get(status["lastAction"], status["lastAction"]),
        ))
    if status.get("lastError"):
        lines.append("{0}: {1}".format(text(30028, "Ultimo errore"), status["lastError"]))
    if not status["linked"]:
        lines.append("")
        lines.append(text(30025, "Collega Kodi dal profilo TECHAM Replay"))
    return "\n".join(lines)


def show_status():
    xbmcgui.Dialog().ok(TITLE, status_message(get_sync_status()))


def manage_unmatched():
    items = get_unmatched_items()
    if not items:
        xbmcgui.Dialog().ok(TITLE, text(30080, "Tutti gli elementi hanno un identificativo TMDb."))
        return
    choice = xbmcgui.Dialog().select(
        TITLE,
        ["{0}: {1}".format("Film" if item.get("kind") == "movie" else "Serie", item.get("title", "")) for item in items],
    )
    if choice < 0:
        return
    value = xbmcgui.Dialog().input(
        text(30081, "Inserisci l'identificativo numerico TMDb"),
        type=xbmcgui.INPUT_NUMERIC,
    )
    try:
        tmdb_id = int(value)
        if tmdb_id <= 0:
            raise ValueError()
        save_manual_mapping(items[choice], tmdb_id)
    except (TypeError, ValueError, OSError):
        xbmcgui.Dialog().ok(TITLE, text(30082, "Identificativo TMDb non valido."))
        return
    success, result = sync_library_now()
    xbmcgui.Dialog().ok(
        TITLE,
        text(30083, "Associazione salvata. Elementi aggiornati: {0}.").format(result.get("changed", 0))
        if success else text(30074, "Sincronizzazione libreria non riuscita. Verifica collegamento e connessione."),
    )


def show_history():
    history = get_sync_history()
    if not history:
        xbmcgui.Dialog().ok(TITLE, text(30084, "Nessuna sincronizzazione registrata."))
        return
    lines = []
    for item in history[:10]:
        stats = item.get("stats", {}) if isinstance(item, dict) else {}
        lines.append("{0} · {1} · {2}: {3}".format(
            format_timestamp(item.get("timestamp")),
            "OK" if item.get("success") else "ERRORE",
            text(30069, "Modifiche"),
            stats.get("changed", 0),
        ))
    xbmcgui.Dialog().textviewer(text(30085, "Cronologia sincronizzazioni"), "\n".join(lines))


def run():
    while True:
        status = get_sync_status()
        actions = [(
            "{0}: {1} — {2}: {3}".format(
                text(30029, "Versione"),
                status["version"],
                text(30066, "Ultima disponibile"),
                status.get("availableVersion") or "—",
            ),
            "status",
        )]
        if status["linked"]:
            actions.append((text(30086, "Apri Replay Hub"), "hub"))
            actions.append((text(30011, "Verifica connessione"), "test"))
        else:
            actions.append((text(30032, "Collega Kodi"), "link"))
        actions.extend([
            (text(30061, "Controlla aggiornamenti"), "updates"),
            (text(30054, "Novità della versione"), "news"),
            (text(30012, "Invia ora gli elementi in attesa"), "flush"),
            (text(30013, "Apri impostazioni"), "settings"),
        ])
        if status["linked"]:
            actions.insert(2, (text(30062, "Sincronizza libreria ora"), "library"))
            actions.insert(3, (text(30087, "Associa contenuti senza TMDb"), "unmatched"))
            actions.insert(4, (text(30085, "Cronologia sincronizzazioni"), "history"))
        if status["linked"]:
            actions.append((text(30037, "Disconnetti Kodi"), "disconnect"))
        choice = xbmcgui.Dialog().select(TITLE, [label for label, _ in actions])
        if choice < 0:
            return
        action = actions[choice][1]
        if action == "status":
            show_status()
        elif action == "hub":
            show_hub()
        elif action == "unmatched":
            manage_unmatched()
        elif action == "history":
            show_history()
        elif action == "link":
            code = xbmcgui.Dialog().input(
                text(30033, "Inserisci il codice Kodi di 10 caratteri"),
                type=xbmcgui.INPUT_ALPHANUM,
            )
            if not code:
                continue
            success, reason = connect_with_code(code)
            if success:
                xbmcgui.Dialog().ok(TITLE, text(30036, "Kodi collegato correttamente"))
            elif reason == "invalid_code":
                xbmcgui.Dialog().ok(TITLE, text(30034, "Il codice inserito non è valido"))
            elif reason == "invalid_url":
                xbmcgui.Dialog().ok(TITLE, text(30042, "L'indirizzo API non è valido"))
            else:
                xbmcgui.Dialog().ok(TITLE, text(30035, "Collegamento non riuscito: genera un nuovo codice"))
        elif action == "test":
            success, reason = test_connection()
            if success:
                xbmcgui.Dialog().ok(TITLE, text(30021, "Connessione riuscita"))
            elif reason == "not_linked":
                xbmcgui.Dialog().ok(TITLE, text(30025, "Collega Kodi dal profilo TECHAM Replay"))
            else:
                xbmcgui.Dialog().ok(
                    TITLE,
                    "{0}: {1}".format(text(30022, "Connessione non riuscita"), reason),
                )
        elif action == "updates":
            refresh_repository()
            success, result = check_for_updates(notify=False)
            if not success:
                xbmcgui.Dialog().ok(
                    TITLE,
                    text(30070, "Controllo aggiornamenti non riuscito. Riprova tra poco."),
                )
                continue
            current = result["current"]
            available = result["available"]
            message = (
                text(30071, "Aggiornamento {0} disponibile. Kodi lo installerà in base alle impostazioni degli aggiornamenti.").format(available)
                if result["updateAvailable"]
                else text(30072, "Hai già la versione più recente: {0}.").format(current)
            )
            xbmcgui.Dialog().ok(TITLE, message)
        elif action == "library":
            success, result = sync_library_now()
            if success:
                xbmcgui.Dialog().ok(
                    TITLE,
                    text(30073, "Sincronizzazione completata: {0} elementi aggiornati.").format(
                        result.get("changed", 0)
                    ),
                )
            else:
                xbmcgui.Dialog().ok(
                    TITLE,
                    text(30074, "Sincronizzazione libreria non riuscita. Verifica collegamento e connessione."),
                )
        elif action == "news":
            xbmcgui.Dialog().ok(
                TITLE,
                text(
                    30077,
                    "Versione 2.0: Replay Hub, profili Kodi, sincronizzazione remota, "
                    "associazione manuale TMDb, cronologia, recupero errori e librerie grandi.",
                ),
            )
        elif action == "flush":
            success = flush_pending_progress()
            message = text(30023, "Coda in attesa inviata") if success else text(
                30024,
                "Alcuni elementi sono ancora in attesa",
            )
            xbmcgui.Dialog().ok(TITLE, message)
        elif action == "settings":
            ADDON.openSettings()
        elif action == "disconnect":
            if not xbmcgui.Dialog().yesno(
                TITLE,
                text(30038, "Disconnettere questo Kodi dal profilo TECHAM Replay?"),
            ):
                continue
            success, reason = disconnect_device()
            if success:
                xbmcgui.Dialog().ok(TITLE, text(30039, "Kodi disconnesso"))
                continue
            force_local = xbmcgui.Dialog().yesno(
                TITLE,
                text(30040, "Il server non è raggiungibile."),
                text(30041, "Disconnettere soltanto questo Kodi? La coda sarà conservata."),
            )
            if force_local:
                disconnect_device(force_local=True)
                xbmcgui.Dialog().ok(TITLE, text(30039, "Kodi disconnesso"))


if __name__ == "__main__":
    run()
