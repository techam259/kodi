# TECHAM Replay Sync per Kodi

Questo add-on di servizio osserva i contenuti riprodotti in Kodi e li invia al profilo TECHAM Replay associato. Non offre film, streaming o sorgenti video: sincronizza esclusivamente lo stato personale di visione.

## Stato iniziale

- Compatibile con Kodi Matrix (19) e successivi, tramite Python 3.
- Salva periodicamente l'avanzamento e propone di riprendere dal punto raggiunto su un altro dispositivo.
- Registra film ed episodi quando raggiungono la soglia di completamento configurata.
- Conserva una coda offline deduplicata e la invia automaticamente quando torna la connessione.
- Supporta la libreria Kodi e gli add-on di riproduzione che espongono metadati TMDb, incluso Stream4Me.
- Richiede l'identificativo TMDb nei metadati passati al player Kodi.
- Richiede il rilascio del sito Replay con le API Kodi e le tabelle SQL comprese nel progetto web.

## Protocollo API previsto

L'utente apre `https://replay.techamstudio.com/kodi`, genera un codice monouso e lo inserisce nelle impostazioni dell'add-on. Kodi lo scambia una sola volta con un token dispositivo, memorizzato solo nelle impostazioni locali di Kodi.

Richiesta autenticata con `Authorization: Bearer <token-dispositivo>`:

```json
{
  "mediaType": "episode",
  "tmdbId": 1399,
  "season": 1,
  "episode": 3,
  "positionSeconds": 1560,
  "durationSeconds": 2700,
  "percentage": 57.78,
  "watched": false
}
```

Il server verifica il token, ricava l'utente e conserva il punto di ripresa. Quando `watched` diventa `true`, aggiorna anche la stessa tabella `episodes` o `library` usata dal sito.

## Installazione dopo il rilascio

1. Comprimi la cartella `plugin.video.techamreplay` in un file ZIP mantenendo la cartella interna.
2. In Kodi apri **Add-on → Installa da file ZIP**.
3. Apri le impostazioni dell'add-on e collega l'account quando sarà disponibile la procedura guidata.
