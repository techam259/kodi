"""Funzioni pure per interpretare metadati e avanzamento di riproduzione."""


def positive_int(value):
    """Restituisce un intero positivo oppure zero per valori non validi."""
    if isinstance(value, bool) or value is None:
        return 0
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        return 0
    return number if number > 0 else 0


def _tmdb_id(value):
    if isinstance(value, (list, tuple)):
        for candidate in value:
            result = _tmdb_id(candidate)
            if result:
                return result
        return 0
    if value is None:
        return 0
    text = str(value).strip().lower()
    for prefix in ("tmdb:", "tmdb-", "tmdb_", "tmdb"):
        if text.startswith(prefix):
            text = text[len(prefix):].strip()
            break
    return positive_int(text)


def extract_tmdb_id(item):
    unique_ids = item.get("uniqueid", {})
    if not isinstance(unique_ids, dict):
        unique_ids = {}
    candidates = (
        unique_ids.get("tmdb"),
        item.get("productioncode"),
        item.get("tmdb_id"),
        item.get("tmdbid"),
        item.get("imdbnumber"),
    )
    for candidate in candidates:
        tmdb_id = _tmdb_id(candidate)
        if tmdb_id:
            return tmdb_id
    return 0


def build_payload(item):
    """Converte l'elemento riprodotto da Kodi nel payload dell'API Replay."""
    if not isinstance(item, dict):
        return None
    media_type = str(item.get("type") or item.get("mediatype") or "").lower()
    season = positive_int(item.get("season"))
    episode = positive_int(item.get("episode"))
    if media_type not in ("movie", "episode"):
        if season and episode:
            media_type = "episode"
        else:
            return None

    tmdb_id = extract_tmdb_id(item)
    if not tmdb_id:
        return None
    if media_type == "episode":
        if not season or not episode:
            return None
        return {
            "mediaType": "episode",
            "tmdbId": tmdb_id,
            "season": season,
            "episode": episode,
            "seriesTitle": item.get("showtitle", ""),
            "watched": True,
        }
    return {
        "mediaType": "movie",
        "tmdbId": tmdb_id,
        "title": item.get("title") or item.get("label", ""),
        "watched": True,
    }


def time_to_seconds(value):
    """Converte un tempo Kodi JSON-RPC in secondi interi."""
    if isinstance(value, bool) or value is None:
        return 0
    if isinstance(value, (int, float)):
        return max(0, int(value))
    if not isinstance(value, dict):
        return 0
    try:
        return max(0, int(
            (float(value.get("hours", 0)) * 3600)
            + (float(value.get("minutes", 0)) * 60)
            + float(value.get("seconds", 0))
            + (float(value.get("milliseconds", 0)) / 1000)
        ))
    except (TypeError, ValueError):
        return 0


def seconds_to_time(value):
    """Converte secondi nel formato richiesto da ``Player.Seek``."""
    try:
        total = max(0, int(float(value)))
    except (TypeError, ValueError):
        total = 0
    return {
        "hours": total // 3600,
        "minutes": (total % 3600) // 60,
        "seconds": total % 60,
        "milliseconds": 0,
    }


def build_progress_payload(identity, position, duration, percentage, watched=False):
    """Aggiunge a un'identita media il progresso normalizzato."""
    if not identity:
        return None
    try:
        position_seconds = max(0, int(float(position)))
    except (TypeError, ValueError):
        position_seconds = 0
    try:
        duration_seconds = max(0, int(float(duration)))
    except (TypeError, ValueError):
        duration_seconds = 0
    if duration_seconds:
        position_seconds = min(position_seconds, duration_seconds)
    try:
        played = min(100.0, max(0.0, float(percentage)))
    except (TypeError, ValueError):
        played = 0.0
    if not played and duration_seconds:
        played = min(100.0, (position_seconds / float(duration_seconds)) * 100.0)

    payload = dict(identity)
    payload.update({
        "positionSeconds": position_seconds,
        "durationSeconds": duration_seconds,
        "percentage": round(played, 2),
        "watched": bool(watched),
    })
    return payload


def payload_signature(payload):
    if not payload:
        return None
    return (
        payload.get("mediaType"),
        payload.get("tmdbId"),
        payload.get("season", 0),
        payload.get("episode", 0),
    )


def playback_complete(percentage, threshold, ended=False):
    """True quando Kodi termina naturalmente o raggiunge la soglia configurata."""
    if ended:
        return True
    try:
        played = float(percentage)
        required = min(100.0, max(50.0, float(threshold)))
    except (TypeError, ValueError):
        return False
    return played >= required


def resume_position(progress, current_position, current_duration, minimum_seconds=60):
    """Restituisce il punto remoto riprendibile, oppure zero."""
    if not isinstance(progress, dict) or progress.get("completed"):
        return 0
    try:
        remote_position = max(0, int(float(progress.get("positionSeconds", 0))))
        remote_duration = max(0, int(float(progress.get("durationSeconds", 0))))
        local_position = max(0, int(float(current_position)))
        local_duration = max(0, int(float(current_duration)))
        minimum = max(15, int(float(minimum_seconds)))
    except (TypeError, ValueError):
        return 0

    duration = local_duration or remote_duration
    if not duration:
        return 0
    if remote_position < minimum or remote_position >= duration - minimum:
        return 0
    if remote_position <= local_position + 15:
        return 0
    return remote_position
