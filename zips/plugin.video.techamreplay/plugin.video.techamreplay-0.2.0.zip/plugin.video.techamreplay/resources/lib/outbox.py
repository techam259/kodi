"""Coda deduplicata degli avanzamenti da inviare quando torna la rete."""


def progress_key(payload):
    if not isinstance(payload, dict):
        return None
    return (
        payload.get("mediaType"),
        payload.get("tmdbId"),
        payload.get("season", 0),
        payload.get("episode", 0),
    )


def _percentage(payload):
    try:
        return max(0.0, float(payload.get("percentage", 0)))
    except (AttributeError, TypeError, ValueError):
        return 0.0


def newer_progress(current, incoming):
    """Mantiene completamenti e avanzamenti maggiori per la stessa opera."""
    if not current:
        return incoming
    if current.get("watched") and not incoming.get("watched"):
        return current
    if incoming.get("watched"):
        return incoming
    return incoming if _percentage(incoming) >= _percentage(current) else current


def merge_queue(entries, incoming, limit=100):
    """Inserisce un payload, sostituendo quello meno recente della stessa opera."""
    if not isinstance(incoming, dict) or not progress_key(incoming):
        return list(entries or [])
    result = []
    matched = False
    for entry in entries or []:
        if progress_key(entry) == progress_key(incoming):
            if not matched:
                result.append(newer_progress(entry, incoming))
                matched = True
        else:
            result.append(entry)
    if not matched:
        result.append(incoming)
    maximum = max(1, int(limit))
    return result[-maximum:]
