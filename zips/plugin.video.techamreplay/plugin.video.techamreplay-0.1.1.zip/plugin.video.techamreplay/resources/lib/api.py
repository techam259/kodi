"""Client HTTP minimale per l'API privata di TECHAM Replay."""

import json
import urllib.error
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()


def sync_progress(payload):
    """Invia un singolo aggiornamento senza bloccare Kodi a lungo."""
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    token = get_device_token(base_url)
    if not base_url or not token:
        log("Sincronizzazione non configurata: apri replay.techamstudio.com/kodi e inserisci il codice.")
        return False

    request = urllib.request.Request(
        base_url + "/progress",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
            "User-Agent": "TECHAM-Replay-Kodi/0.1.0",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            if 200 <= response.status < 300:
                return True
            log("API Replay: risposta HTTP {0}".format(response.status), xbmc.LOGWARNING)
    except urllib.error.HTTPError as error:
        log("API Replay: risposta HTTP {0}".format(error.code), xbmc.LOGWARNING)
    except (urllib.error.URLError, ValueError) as error:
        log("API Replay non raggiungibile: {0}".format(error), xbmc.LOGWARNING)
    return False


def get_device_token(base_url):
    token = ADDON.getSettingString("access_token").strip()
    if token:
        return token
    code = ADDON.getSettingString("link_code").strip().upper()
    if not code:
        return ""
    request = urllib.request.Request(
        base_url + "/session",
        data=json.dumps({"code": code, "deviceName": "Kodi"}).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": "TECHAM-Replay-Kodi/0.1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            data = json.loads(response.read().decode("utf-8"))
            token = data.get("token", "")
            if token:
                ADDON.setSettingString("access_token", token)
                ADDON.setSettingString("link_code", "")
                log("Kodi collegato al profilo TECHAM Replay.")
                xbmcgui.Dialog().notification(
                    "TECHAM Replay",
                    "Kodi collegato al tuo profilo.",
                    time=5000,
                )
                return token
    except (urllib.error.HTTPError, urllib.error.URLError, ValueError) as error:
        log("Collegamento Kodi non riuscito: {0}".format(error), xbmc.LOGWARNING)
    return ""


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[TECHAM Replay Sync] " + message, level)
