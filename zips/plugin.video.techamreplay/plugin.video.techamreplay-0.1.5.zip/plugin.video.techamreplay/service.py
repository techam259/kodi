"""Servizio Kodi: sincronizza film ed episodi visti con TECHAM Replay."""

import json
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui

ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))

from api import get_device_token, log, sync_progress, update_device_name  # noqa: E402
from playback import build_payload, payload_signature, playback_complete, positive_int  # noqa: E402


ADDON = xbmcaddon.Addon()
PLAYER_ITEM_PROPERTIES = [
    "title",
    "showtitle",
    "season",
    "episode",
    "uniqueid",
    "imdbnumber",
    "productioncode",
    "file",
]


class PlaybackTracker:
    """Conserva i metadati mentre Kodi riproduce anche contenuti esterni alla libreria."""

    def __init__(self):
        self.reset()

    def reset(self):
        self.payload = None
        self.signature = None
        self.source_key = None
        self.max_percentage = 0.0
        self.synced = False
        self.next_sync_attempt = 0.0
        self.player_active = False

    def poll(self):
        if not ADDON.getSettingBool("enabled"):
            self.reset()
            return

        player_id = self._active_video_player_id()
        if player_id is None:
            if self.player_active:
                self.finish(False)
            return

        self.player_active = True
        item = json_rpc("Player.GetItem", {
            "playerid": player_id,
            "properties": PLAYER_ITEM_PROPERTIES,
        }).get("item", {})
        payload, source_key = self._payload_for_item(item)

        if payload:
            signature = payload_signature(payload)
            if self.signature and signature != self.signature:
                self.finish(False)
                self.player_active = True
            self.payload = payload
            self.signature = signature
            self.source_key = source_key

        properties = json_rpc("Player.GetProperties", {
            "playerid": player_id,
            "properties": ["percentage"],
        })
        try:
            percentage = float(properties.get("percentage", 0.0))
        except (TypeError, ValueError):
            percentage = 0.0
        self.max_percentage = max(self.max_percentage, percentage)

        if self.payload and playback_complete(
            self.max_percentage,
            ADDON.getSettingInt("completion_threshold"),
        ):
            self._sync()

    def finish(self, ended):
        """Conclude la riproduzione e restituisce True se l'elemento è stato sincronizzato."""
        handled = self.synced
        if self.payload and not self.synced and playback_complete(
            self.max_percentage,
            ADDON.getSettingInt("completion_threshold"),
            ended=ended,
        ):
            handled = self._sync(force=True)
        self.reset()
        return handled

    def _active_video_player_id(self):
        players = json_rpc("Player.GetActivePlayers")
        if not isinstance(players, list):
            return None
        for player in players:
            if player.get("type") == "video":
                return player.get("playerid")
        return None

    def _payload_for_item(self, item):
        media_type = str(item.get("type", "")).lower()
        library_id = positive_int(item.get("id"))
        if media_type in ("movie", "episode") and library_id:
            source_key = ("library", media_type, library_id)
            if source_key == self.source_key and self.payload:
                return self.payload, source_key
            return library_payload(media_type, library_id), source_key

        payload = build_payload(item)
        if not payload:
            return None, None
        return payload, ("player", payload_signature(payload))

    def _sync(self, force=False):
        if not self.payload:
            return False
        if self.synced:
            return True

        now = time.monotonic()
        if not force and now < self.next_sync_attempt:
            return False
        self.next_sync_attempt = now + 30.0
        if not sync_progress(self.payload):
            return False

        self.synced = True
        media_label = "Episodio" if self.payload["mediaType"] == "episode" else "Film"
        log("{0} sincronizzato come visto.".format(media_label))
        xbmcgui.Dialog().notification(
            "TECHAM Replay",
            "{0} segnato come visto.".format(media_label),
            time=4000,
        )
        return True


class ReplayMonitor(xbmc.Monitor):
    def __init__(self, tracker):
        super().__init__()
        self.tracker = tracker

    def onNotification(self, sender, method, data):
        if method != "Player.OnStop" or not ADDON.getSettingBool("enabled"):
            return

        try:
            notification = json.loads(data)
            item = notification.get("item", {})
            media_type = item.get("type")
            library_id = positive_int(item.get("id"))
            ended = bool(notification.get("end", False))
            handled = self.tracker.finish(ended)
            if not handled and ended and media_type in ("movie", "episode") and library_id:
                payload = library_payload(media_type, library_id)
                if payload:
                    sync_progress(payload)
        except (TypeError, ValueError, KeyError) as error:
            log("Evento Kodi non leggibile: {0}".format(error), xbmc.LOGWARNING)


def library_payload(media_type, library_id):
    """Crea il payload corretto per gli elementi presenti nella libreria Kodi."""
    if media_type == "movie":
        result = json_rpc("VideoLibrary.GetMovieDetails", {
            "movieid": library_id,
            "properties": ["uniqueid", "title"],
        })
        details = result.get("moviedetails", {})
        tmdb_id = positive_int(details.get("uniqueid", {}).get("tmdb"))
        if not tmdb_id:
            log("Film ignorato: manca l'identificativo TMDb in Kodi.", xbmc.LOGDEBUG)
            return None
        return {
            "mediaType": "movie",
            "tmdbId": tmdb_id,
            "title": details.get("title", ""),
            "watched": True,
        }

    result = json_rpc("VideoLibrary.GetEpisodeDetails", {
        "episodeid": library_id,
        "properties": ["tvshowid", "season", "episode", "showtitle"],
    })
    details = result.get("episodedetails", {})
    tvshow_id = positive_int(details.get("tvshowid"))
    season = positive_int(details.get("season"))
    episode = positive_int(details.get("episode"))
    if not tvshow_id or not season or not episode:
        return None

    show = json_rpc("VideoLibrary.GetTVShowDetails", {
        "tvshowid": tvshow_id,
        "properties": ["uniqueid", "title"],
    }).get("tvshowdetails", {})
    tmdb_id = positive_int(show.get("uniqueid", {}).get("tmdb"))
    if not tmdb_id:
        log("Episodio ignorato: manca l'identificativo TMDb della serie in Kodi.", xbmc.LOGDEBUG)
        return None
    return {
        "mediaType": "episode",
        "tmdbId": tmdb_id,
        "season": season,
        "episode": episode,
        "seriesTitle": details.get("showtitle") or show.get("title", ""),
        "watched": True,
    }


def json_rpc(method, params=None):
    query = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        query["params"] = params
    try:
        response = xbmc.executeJSONRPC(json.dumps(query))
        parsed = json.loads(response)
        return parsed.get("result", {})
    except (TypeError, ValueError):
        return {}


def link_device_if_needed():
    """Scambia il codice appena viene salvato nelle impostazioni."""
    if ADDON.getSettingString("access_token").strip():
        return
    if not ADDON.getSettingString("link_code").strip():
        return
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    if base_url:
        get_device_token(base_url)


def sync_device_name():
    """Mantiene aggiornato nel profilo il nome dell'istanza Kodi."""
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    token = ADDON.getSettingString("access_token").strip()
    if not base_url or not token:
        return False
    return update_device_name(base_url, token)


if __name__ == "__main__":
    tracker = PlaybackTracker()
    monitor = ReplayMonitor(tracker)
    log("Servizio avviato.")
    next_link_attempt = 0.0
    next_device_name_sync = 0.0
    while not monitor.abortRequested():
        now = time.monotonic()
        if now >= next_link_attempt:
            link_device_if_needed()
            next_link_attempt = now + 15.0
        if now >= next_device_name_sync:
            updated = sync_device_name()
            next_device_name_sync = now + (21600.0 if updated else 60.0)
        tracker.poll()
        if monitor.waitForAbort(1):
            break
