"""Funzioni pure per interpretare i metadati e la percentuale di riproduzione."""


def positive_int(value):
    """Restituisce un intero positivo oppure zero per valori non validi."""
    if isinstance(value, bool) or value is None:
        return 0
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        return 0
    return number if number > 0 else 0


def _tmdb_id(value):
    if isinstance(value, (list, tuple)):
        for candidate in value:
            result = _tmdb_id(candidate)
            if result:
                return result
        return 0
    if value is None:
        return 0
    text = str(value).strip().lower()
    for prefix in ("tmdb:", "tmdb-", "tmdb_", "tmdb"):
        if text.startswith(prefix):
            text = text[len(prefix):].strip()
            break
    return positive_int(text)


def extract_tmdb_id(item):
    unique_ids = item.get("uniqueid", {})
    if not isinstance(unique_ids, dict):
        unique_ids = {}
    candidates = (
        unique_ids.get("tmdb"),
        item.get("productioncode"),
        item.get("tmdb_id"),
        item.get("tmdbid"),
        item.get("imdbnumber"),
    )
    for candidate in candidates:
        tmdb_id = _tmdb_id(candidate)
        if tmdb_id:
            return tmdb_id
    return 0


def build_payload(item):
    """Converte l'elemento riprodotto da Kodi nel payload dell'API Replay."""
    if not isinstance(item, dict):
        return None
    media_type = str(item.get("type") or item.get("mediatype") or "").lower()
    season = positive_int(item.get("season"))
    episode = positive_int(item.get("episode"))
    if media_type not in ("movie", "episode"):
        if season and episode:
            media_type = "episode"
        else:
            return None

    tmdb_id = extract_tmdb_id(item)
    if not tmdb_id:
        return None
    if media_type == "episode":
        if not season or not episode:
            return None
        return {
            "mediaType": "episode",
            "tmdbId": tmdb_id,
            "season": season,
            "episode": episode,
            "seriesTitle": item.get("showtitle", ""),
            "watched": True,
        }
    return {
        "mediaType": "movie",
        "tmdbId": tmdb_id,
        "title": item.get("title") or item.get("label", ""),
        "watched": True,
    }


def payload_signature(payload):
    if not payload:
        return None
    return (
        payload.get("mediaType"),
        payload.get("tmdbId"),
        payload.get("season", 0),
        payload.get("episode", 0),
    )


def playback_complete(percentage, threshold, ended=False):
    """True quando Kodi termina naturalmente o raggiunge la soglia configurata."""
    if ended:
        return True
    try:
        played = float(percentage)
        required = min(100.0, max(50.0, float(threshold)))
    except (TypeError, ValueError):
        return False
    return played >= required
