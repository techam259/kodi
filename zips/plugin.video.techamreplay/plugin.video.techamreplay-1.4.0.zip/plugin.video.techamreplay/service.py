"""Servizio Kodi: sincronizza visione e punto di ripresa con TECHAM Replay."""

import json
import os
import sys
import time
import threading
from functools import wraps

import xbmc
import xbmcaddon
import xbmcgui

ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))

from api import (  # noqa: E402
    claim_release_notice,
    flush_pending_progress,
    get_api_base_url,
    get_device_token,
    get_remote_progress,
    log,
    sync_progress,
    update_device_name,
)
from kodi_rpc import json_rpc  # noqa: E402
from library_sync import sync_now as sync_library_now  # noqa: E402
from playback import (  # noqa: E402
    build_payload,
    build_progress_payload,
    payload_signature,
    playback_complete,
    non_negative_int,
    positive_int,
    resume_position,
    seconds_to_time,
    should_finish_on_stop,
    time_to_seconds,
)
from updates import check_for_updates, refresh_repository  # noqa: E402


ADDON = xbmcaddon.Addon()
PLAYER_ITEM_PROPERTIES = [
    "title",
    "showtitle",
    "season",
    "episode",
    "uniqueid",
    "imdbnumber",
    "productioncode",
    "file",
]


def tracker_locked(function):
    @wraps(function)
    def call(self, *args, **kwargs):
        with self.lock:
            return function(self, *args, **kwargs)
    return call


class PlaybackTracker:
    """Conserva i metadati anche per i contenuti riprodotti da add-on esterni."""

    def __init__(self):
        self.lock = threading.RLock()
        self.reset()

    def reset(self):
        self.payload = None
        self.signature = None
        self.source_key = None
        self.playing_file = None
        self.max_percentage = 0.0
        self.position_seconds = 0
        self.duration_seconds = 0
        self.synced = False
        self.next_completion_attempt = 0.0
        self.last_progress_sync_at = 0.0
        self.last_progress_percentage = -1.0
        self.resume_checked_signature = None
        self.player_active = False

    @tracker_locked
    def poll(self):
        if not ADDON.getSettingBool("enabled"):
            self.reset()
            return

        player_id = self._active_video_player_id()
        if player_id is None:
            if self.player_active:
                self.finish(False)
            return

        self.player_active = True
        item = json_rpc("Player.GetItem", {
            "playerid": player_id,
            "properties": PLAYER_ITEM_PROPERTIES,
        }).get("item", {})
        current_file = item.get("file") or None
        if self.playing_file and current_file and current_file != self.playing_file:
            self.finish(False)
            self.player_active = True
        if current_file:
            self.playing_file = current_file
        payload, source_key = self._payload_for_item(item)
        if payload:
            signature = payload_signature(payload)
            if self.signature and signature != self.signature:
                self.finish(False)
                self.player_active = True
            self.payload = payload
            self.signature = signature
            self.source_key = source_key

        properties = json_rpc("Player.GetProperties", {
            "playerid": player_id,
            "properties": ["percentage", "time", "totaltime", "canseek"],
        })
        try:
            percentage = float(properties.get("percentage", 0.0))
        except (TypeError, ValueError):
            percentage = 0.0
        self.position_seconds = time_to_seconds(properties.get("time"))
        self.duration_seconds = time_to_seconds(properties.get("totaltime"))
        if not percentage and self.duration_seconds:
            percentage = (self.position_seconds / float(self.duration_seconds)) * 100.0
        self.max_percentage = max(self.max_percentage, percentage)

        if self.payload and self.resume_checked_signature != self.signature:
            self._offer_resume(player_id, bool(properties.get("canseek")))

        if self.payload and playback_complete(
            self.max_percentage,
            ADDON.getSettingInt("completion_threshold"),
        ):
            self._sync_complete()
        else:
            self._sync_partial()

    @tracker_locked
    def finish(self, ended):
        """Salva l'ultimo avanzamento e conclude la riproduzione corrente."""
        handled = self.synced
        if self.payload and not self.synced:
            if playback_complete(
                self.max_percentage,
                ADDON.getSettingInt("completion_threshold"),
                ended=ended,
            ):
                handled = self._sync_complete(force=True)
            else:
                self._sync_partial(force=True)
        self.reset()
        return handled

    def _active_video_player_id(self):
        players = json_rpc("Player.GetActivePlayers")
        if not isinstance(players, list):
            return None
        for player in players:
            if player.get("type") == "video":
                return player.get("playerid")
        return None

    def _payload_for_item(self, item):
        media_type = str(item.get("type", "")).lower()
        library_id = positive_int(item.get("id"))
        if media_type in ("movie", "episode") and library_id:
            source_key = ("library", media_type, library_id)
            if source_key == self.source_key and self.payload:
                return self.payload, source_key
            return library_payload(media_type, library_id), source_key

        payload = build_payload(item)
        if not payload:
            return None, None
        return payload, ("player", payload_signature(payload))

    def _offer_resume(self, player_id, can_seek):
        if self.resume_checked_signature == self.signature:
            return
        if not ADDON.getSettingBool("resume_enabled"):
            self.resume_checked_signature = self.signature
            return
        if not can_seek or self.duration_seconds < 60:
            return
        self.resume_checked_signature = self.signature

        progress = get_remote_progress(self.payload)
        target = resume_position(
            progress,
            self.position_seconds,
            self.duration_seconds,
        )
        if not target:
            return
        if not xbmcgui.Dialog().yesno(
            "TECHAM Replay",
            "Riprendere la visione da {0}?".format(format_time(target)),
        ):
            return

        json_rpc("Player.Seek", {
            "playerid": player_id,
            "value": {"time": seconds_to_time(target)},
        })
        self.position_seconds = target
        if self.duration_seconds:
            self.max_percentage = max(
                self.max_percentage,
                (target / float(self.duration_seconds)) * 100.0,
            )
        log("Riproduzione ripresa da {0}.".format(format_time(target)))

    def _sync_partial(self, force=False):
        if not self.payload or self.synced:
            return False
        if self.duration_seconds < 60 or self.position_seconds < 10:
            return False

        now = time.monotonic()
        interval = max(30, ADDON.getSettingInt("progress_sync_interval"))
        if not force and now - self.last_progress_sync_at < interval:
            return False
        if not force and self.max_percentage < self.last_progress_percentage + 0.25:
            return False

        payload = build_progress_payload(
            self.payload,
            self.position_seconds,
            self.duration_seconds,
            self.max_percentage,
            watched=False,
        )
        self.last_progress_sync_at = now
        self.last_progress_percentage = self.max_percentage
        return sync_progress(payload)

    def _sync_complete(self, force=False):
        if not self.payload:
            return False
        if self.synced:
            return True

        now = time.monotonic()
        if not force and now < self.next_completion_attempt:
            return False
        self.next_completion_attempt = now + 30.0
        payload = build_progress_payload(
            self.payload,
            self.position_seconds,
            self.duration_seconds,
            self.max_percentage,
            watched=True,
        )
        if not sync_progress(payload):
            return False

        self.synced = True
        media_label = "Episodio" if self.payload["mediaType"] == "episode" else "Film"
        log("{0} sincronizzato come visto.".format(media_label))
        if ADDON.getSettingBool("notify_sync"):
            xbmcgui.Dialog().notification(
                "TECHAM Replay",
                "{0} segnato come visto.".format(media_label),
                time=4000,
            )
        return True


class ReplayMonitor(xbmc.Monitor):
    def __init__(self, tracker):
        super().__init__()
        self.tracker = tracker

    def onNotification(self, sender, method, data):
        if method != "Player.OnStop" or not ADDON.getSettingBool("enabled"):
            return

        try:
            with self.tracker.lock:
                self._handle_stop(data)
        except (TypeError, ValueError, KeyError) as error:
            log("Evento Kodi non leggibile: {0}".format(error), xbmc.LOGWARNING)

    def _handle_stop(self, data):
        notification = json.loads(data)
        item = notification.get("item", {})
        ended = bool(notification.get("end", False))
        event_payload, event_source_key = self.tracker._payload_for_item(item)
        has_active_player = self.tracker._active_video_player_id() is not None
        handled = False

        if should_finish_on_stop(
            self.tracker.source_key,
            event_source_key,
            has_active_player,
        ):
            handled = self.tracker.finish(ended)

        if not handled and ended and event_payload:
            sync_progress(build_progress_payload(
                event_payload,
                0,
                0,
                100,
                watched=True,
            ))



def library_payload(media_type, library_id):
    """Crea l'identita Replay per gli elementi presenti nella libreria Kodi."""
    if media_type == "movie":
        result = json_rpc("VideoLibrary.GetMovieDetails", {
            "movieid": library_id,
            "properties": ["uniqueid", "title"],
        })
        details = result.get("moviedetails", {})
        tmdb_id = positive_int(details.get("uniqueid", {}).get("tmdb"))
        if not tmdb_id:
            log("Film ignorato: manca l'identificativo TMDb in Kodi.", xbmc.LOGDEBUG)
            return None
        return {
            "mediaType": "movie",
            "tmdbId": tmdb_id,
            "title": details.get("title", ""),
            "watched": True,
        }

    result = json_rpc("VideoLibrary.GetEpisodeDetails", {
        "episodeid": library_id,
        "properties": ["tvshowid", "season", "episode", "showtitle"],
    })
    details = result.get("episodedetails", {})
    tvshow_id = positive_int(details.get("tvshowid"))
    season = non_negative_int(details.get("season"))
    episode = positive_int(details.get("episode"))
    if not tvshow_id or season is None or not episode:
        return None

    show = json_rpc("VideoLibrary.GetTVShowDetails", {
        "tvshowid": tvshow_id,
        "properties": ["uniqueid", "title"],
    }).get("tvshowdetails", {})
    tmdb_id = positive_int(show.get("uniqueid", {}).get("tmdb"))
    if not tmdb_id:
        log("Episodio ignorato: manca l'identificativo TMDb della serie in Kodi.", xbmc.LOGDEBUG)
        return None
    return {
        "mediaType": "episode",
        "tmdbId": tmdb_id,
        "season": season,
        "episode": episode,
        "seriesTitle": details.get("showtitle") or show.get("title", ""),
        "watched": True,
    }


def format_time(seconds):
    value = seconds_to_time(seconds)
    if value["hours"]:
        return "{0}:{1:02d}:{2:02d}".format(
            value["hours"], value["minutes"], value["seconds"]
        )
    return "{0}:{1:02d}".format(value["minutes"], value["seconds"])


def link_device_if_needed():
    """Scambia il codice appena viene salvato nelle impostazioni."""
    if ADDON.getSettingString("access_token").strip():
        return
    if not ADDON.getSettingString("link_code").strip():
        return
    base_url = get_api_base_url()
    if base_url:
        get_device_token(base_url)


def sync_device_name():
    """Mantiene aggiornato nel profilo il nome dell'istanza Kodi."""
    base_url = get_api_base_url()
    token = ADDON.getSettingString("access_token").strip()
    if not base_url or not token:
        return False
    return update_device_name(base_url, token)


def notify_release_if_needed():
    """Mostra una sola notifica per ogni versione installata."""
    if not ADDON.getSettingBool("notify_updates"):
        return False
    version = claim_release_notice()
    if not version:
        return False
    template = ADDON.getLocalizedString(30056) or (
        "TECHAM Replay Sync aggiornato alla versione {0}. "
        "Apri l'add-on per scoprire le novita."
    )
    xbmcgui.Dialog().notification(
        "TECHAM Replay Sync",
        template.format(version),
        time=10000,
    )
    return True


def request_addon_updates():
    """Chiede a Kodi di controllare subito gli aggiornamenti dei repository."""
    return refresh_repository()


if __name__ == "__main__":
    tracker = PlaybackTracker()
    monitor = ReplayMonitor(tracker)
    log("Servizio avviato.")
    request_addon_updates()
    notify_release_if_needed()
    next_link_attempt = 0.0
    next_device_name_sync = 0.0
    next_queue_flush = 0.0
    next_library_sync = 0.0
    next_update_check = 0.0
    while not monitor.abortRequested():
        now = time.monotonic()
        if now >= next_link_attempt:
            link_device_if_needed()
            next_link_attempt = now + 15.0
        if now >= next_device_name_sync:
            updated = sync_device_name()
            next_device_name_sync = now + (21600.0 if updated else 60.0)
        if ADDON.getSettingBool("enabled") and now >= next_queue_flush:
            flush_pending_progress()
            next_queue_flush = now + 60.0
        if now >= next_update_check:
            update_ok, _ = check_for_updates(notify=True)
            next_update_check = now + (21600.0 if update_ok else 600.0)
        if (
            ADDON.getSettingBool("enabled")
            and ADDON.getSettingBool("library_sync_enabled")
            and now >= next_library_sync
        ):
            library_ok, _ = sync_library_now(json_rpc)
            interval = max(300, ADDON.getSettingInt("library_sync_interval"))
            next_library_sync = now + (float(interval) if library_ok else 60.0)
        try:
            tracker.poll()
        except Exception as error:
            # One malformed player response must not terminate all future synchronization.
            log("Rilevamento riproduzione fallito: {0}".format(type(error).__name__), xbmc.LOGWARNING)
        if monitor.waitForAbort(1):
            break
    tracker.finish(False)
