"""Allinea in modo prudente lo stato Replay con la libreria video di Kodi."""

import json
import os

import xbmcaddon
import xbmcgui
import xbmcvfs

from api import (
    claim_content_notices,
    get_remote_library_snapshot,
    log,
    record_library_sync,
)
from kodi_rpc import json_rpc
from playback import non_negative_int, positive_int


ADDON = xbmcaddon.Addon()
STATE_FILE = "library-sync-state.json"


def _profile_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return profile


def _state_path():
    return os.path.join(_profile_path(), STATE_FILE)


def _read_state():
    path = _state_path()
    if not os.path.exists(path):
        return set()
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        managed = data.get("managed", []) if isinstance(data, dict) else []
        return set(value for value in managed if isinstance(value, str))
    except (OSError, TypeError, ValueError):
        return set()


def _write_state(managed):
    path = _state_path()
    temporary = path + ".tmp"
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(
                {"managed": sorted(managed)},
                handle,
                ensure_ascii=False,
                separators=(",", ":"),
            )
        os.replace(temporary, path)
    except OSError as error:
        log("Stato libreria non salvato: {0}".format(error))


def _movie_key(tmdb_id):
    return "movie:{0}".format(tmdb_id)


def _episode_key(tmdb_id, season, episode):
    return "episode:{0}:{1}:{2}".format(tmdb_id, season, episode)


def _remote_keys(snapshot):
    if not isinstance(snapshot.get("completedMovies"), list) or not isinstance(
        snapshot.get("watchedEpisodes"), list
    ):
        raise ValueError("Liste di sincronizzazione mancanti")
    remote = set()
    for item in snapshot.get("completedMovies", []):
        if not isinstance(item, dict):
            continue
        tmdb_id = positive_int(item.get("tmdbId"))
        if tmdb_id:
            remote.add(_movie_key(tmdb_id))
    for item in snapshot.get("watchedEpisodes", []):
        if not isinstance(item, dict):
            continue
        tmdb_id = positive_int(item.get("tmdbId"))
        season = non_negative_int(item.get("season"))
        episode = positive_int(item.get("episode"))
        if tmdb_id and season is not None and episode:
            remote.add(_episode_key(tmdb_id, season, episode))
    return remote


def _local_items(rpc):
    items = {}
    movies_result = rpc("VideoLibrary.GetMovies", {
        "properties": ["uniqueid", "playcount", "title"],
    })
    if not isinstance(movies_result, dict):
        raise ValueError("Libreria film Kodi non disponibile")
    if isinstance(movies_result, dict):
        for movie in movies_result.get("movies", []):
            tmdb_id = positive_int((movie.get("uniqueid") or {}).get("tmdb"))
            movie_id = positive_int(movie.get("movieid"))
            if tmdb_id and movie_id:
                items[_movie_key(tmdb_id)] = {
                    "kind": "movie",
                    "id": movie_id,
                    "playcount": int(movie.get("playcount", 0) or 0),
                }

    show_map = {}
    shows_result = rpc("VideoLibrary.GetTVShows", {
        "properties": ["uniqueid", "title"],
    })
    if not isinstance(shows_result, dict):
        raise ValueError("Libreria serie Kodi non disponibile")
    if isinstance(shows_result, dict):
        for show in shows_result.get("tvshows", []):
            show_id = positive_int(show.get("tvshowid"))
            tmdb_id = positive_int((show.get("uniqueid") or {}).get("tmdb"))
            if show_id and tmdb_id:
                show_map[show_id] = tmdb_id

    episodes_result = rpc("VideoLibrary.GetEpisodes", {
        "properties": ["tvshowid", "season", "episode", "playcount"],
    })
    if not isinstance(episodes_result, dict):
        raise ValueError("Libreria episodi Kodi non disponibile")
    if isinstance(episodes_result, dict):
        for episode_item in episodes_result.get("episodes", []):
            show_id = positive_int(episode_item.get("tvshowid"))
            tmdb_id = show_map.get(show_id)
            season = non_negative_int(episode_item.get("season"))
            episode = positive_int(episode_item.get("episode"))
            episode_id = positive_int(episode_item.get("episodeid"))
            if tmdb_id and season is not None and episode and episode_id:
                items[_episode_key(tmdb_id, season, episode)] = {
                    "kind": "episode",
                    "id": episode_id,
                    "playcount": int(episode_item.get("playcount", 0) or 0),
                }
    return items


def apply_snapshot(snapshot, rpc=json_rpc):
    """Tocca solo elementi gestiti da Replay, lasciando intatta la libreria locale."""
    if not isinstance(snapshot, dict):
        raise ValueError("Snapshot Replay non valido")
    remote = _remote_keys(snapshot)
    previous = _read_state()
    local = _local_items(rpc)
    managed = set()
    changed = watched = unwatched = 0

    for key, item in local.items():
        desired = None
        if key in remote:
            desired = 1
        elif key in previous:
            desired = 0
        if desired is None:
            continue

        current = 1 if item["playcount"] > 0 else 0
        success = current == desired
        if not success:
            method = (
                "VideoLibrary.SetMovieDetails"
                if item["kind"] == "movie"
                else "VideoLibrary.SetEpisodeDetails"
            )
            identifier = "movieid" if item["kind"] == "movie" else "episodeid"
            result = rpc(method, {identifier: item["id"], "playcount": desired})
            success = result == "OK"
            if success:
                changed += 1
                if desired:
                    watched += 1
                else:
                    unwatched += 1

        if desired or not success:
            managed.add(key)

    _write_state(managed)
    return {
        "changed": changed,
        "watched": watched,
        "unwatched": unwatched,
        "scanned": len(local),
        "managed": len(managed),
    }


def _notify_content(notices):
    fresh = claim_content_notices(notices)
    for notice in fresh[:3]:
        title = str(notice.get("seriesTitle") or "Serie TV")
        season = int(notice.get("season", 0) or 0)
        episode = int(notice.get("episode", 0) or 0)
        heading = (
            "Nuova stagione di {0}".format(title)
            if season > 0 and episode == 1
            else "Nuovo episodio di {0}".format(title)
        )
        xbmcgui.Dialog().notification(
            "TECHAM Replay",
            "{0} · S{1:02d}E{2:02d}".format(heading, season, episode),
            time=9000,
        )
    return len(fresh)


def sync_now(rpc=json_rpc):
    """Scarica e applica lo snapshot; restituisce (successo, statistiche)."""
    if not ADDON.getSettingBool("enabled"):
        return False, {"reason": "disabled"}
    if not ADDON.getSettingBool("library_sync_enabled"):
        return False, {"reason": "library_disabled"}

    snapshot = get_remote_library_snapshot()
    if snapshot is None:
        return False, {"reason": "unavailable"}
    try:
        stats = apply_snapshot(snapshot, rpc)
    except (TypeError, ValueError) as error:
        log("Snapshot libreria non valido: {0}".format(error))
        return False, {"reason": "invalid_snapshot"}

    record_library_sync(stats, snapshot.get("serverTime", ""))
    if stats["changed"] and ADDON.getSettingBool("notify_sync"):
        xbmcgui.Dialog().notification(
            "TECHAM Replay",
            "Libreria aggiornata: {0} elementi.".format(stats["changed"]),
            time=6000,
        )
    if ADDON.getSettingBool("notify_content"):
        stats["newContent"] = _notify_content(snapshot.get("newContent", []))
    else:
        stats["newContent"] = 0
    return True, stats
