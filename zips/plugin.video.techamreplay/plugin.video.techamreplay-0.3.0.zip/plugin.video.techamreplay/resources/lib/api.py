"""Client HTTP minimale per l'API privata di TECHAM Replay."""

import json
import os
import threading
from datetime import datetime, timezone
from functools import wraps
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from outbox import merge_queue, progress_key, newer_progress


ADDON = xbmcaddon.Addon()
USER_AGENT = "TECHAM-Replay-Kodi/" + ADDON.getAddonInfo("version")
OUTBOX_FILE = "progress-outbox.json"
STATUS_FILE = "sync-status.json"
_progress_lock = threading.RLock()
_status_lock = threading.RLock()


def serialized(function):
    @wraps(function)
    def call(*args, **kwargs):
        with _progress_lock:
            return function(*args, **kwargs)
    return call


def get_device_name():
    """Restituisce il nome configurato dell'istanza Kodi."""
    name = xbmc.getInfoLabel("System.FriendlyName").strip()
    return name[:80] or "Kodi"


def _profile_path():
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    xbmcvfs.mkdirs(profile)
    return profile


def _outbox_path():
    return os.path.join(_profile_path(), OUTBOX_FILE)


def _status_path():
    return os.path.join(_profile_path(), STATUS_FILE)


def _read_status_file():
    path = _status_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, TypeError, ValueError):
        return {}


def _write_status_file(data):
    path = _status_path()
    temporary = path + ".tmp"
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        os.replace(temporary, path)
    except OSError as error:
        log("Stato sincronizzazione non salvato: {0}".format(error), xbmc.LOGWARNING)


def _record_sync_result(success, action, error=""):
    with _status_lock:
        data = _read_status_file()
        data["lastAttemptAt"] = datetime.now(timezone.utc).isoformat()
        data["lastAction"] = str(action or "sync")[:40]
        if success:
            data["lastSuccessAt"] = data["lastAttemptAt"]
            data["lastError"] = ""
        else:
            data["lastError"] = str(error or "Errore sconosciuto")[:160]
        _write_status_file(data)


def _read_outbox():
    path = _outbox_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, list) else []
    except (OSError, TypeError, ValueError) as error:
        log("Coda offline non leggibile: {0}".format(error), xbmc.LOGWARNING)
        return []


def _write_outbox(entries):
    path = _outbox_path()
    if not entries:
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError as error:
            log("Coda offline non rimossa: {0}".format(error), xbmc.LOGWARNING)
        return
    temporary = path + ".tmp"
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(entries, handle, ensure_ascii=False, separators=(",", ":"))
        os.replace(temporary, path)
    except OSError as error:
        log("Coda offline non salvata: {0}".format(error), xbmc.LOGWARNING)


@serialized
def queue_progress(payload):
    """Accoda un avanzamento senza creare duplicati per la stessa opera."""
    entries = merge_queue(_read_outbox(), payload)
    _write_outbox(entries)
    return len(entries)


def _post_progress(base_url, token, payload):
    request = urllib.request.Request(
        base_url + "/progress",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            success = 200 <= response.status < 300
            if success:
                _record_sync_result(True, "progress")
            return success, False
    except urllib.error.HTTPError as error:
        log("API Replay: risposta HTTP {0}".format(error.code), xbmc.LOGWARNING)
        _record_sync_result(False, "progress", "HTTP {0}".format(error.code))
        retryable = error.code in (401, 403, 408, 429) or error.code >= 500
        return False, retryable
    except (urllib.error.URLError, OSError, ValueError) as error:
        log("API Replay non raggiungibile: {0}".format(error), xbmc.LOGWARNING)
        _record_sync_result(False, "progress", "Servizio non raggiungibile")
        return False, True


@serialized
def sync_progress(payload, queue_on_failure=True):
    """Invia un aggiornamento e lo accoda se il collegamento non è disponibile."""
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    token = get_device_token(base_url) if base_url else ""
    if not base_url or not token:
        if queue_on_failure:
            queue_progress(payload)
        log("Sincronizzazione non configurata: genera un codice dal profilo TECHAM Replay.")
        return False

    # A successful live save must retire older queued data for the same title.
    # Preserve a queued completion if this live update is still partial.
    entries = _read_outbox()
    for entry in entries:
        if progress_key(entry) == progress_key(payload):
            payload = newer_progress(entry, payload)
    success, retryable = _post_progress(base_url, token, payload)
    if success:
        _write_outbox([e for e in entries if progress_key(e) != progress_key(payload)])
    if not success and retryable and queue_on_failure:
        queue_progress(payload)
    return success


@serialized
def flush_pending_progress():
    """Riprova gli aggiornamenti rimasti nella coda offline."""
    entries = _read_outbox()
    if not entries:
        return True
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    token = get_device_token(base_url) if base_url else ""
    if not base_url or not token:
        return False

    pending = []
    sent = 0
    for index, payload in enumerate(entries):
        success, retryable = _post_progress(base_url, token, payload)
        if success:
            sent += 1
        elif retryable:
            # Stop at the first network/auth failure: avoid blocking Kodi for 100 * 8s.
            pending.extend(entries[index:])
            break
    _write_outbox(pending)
    if sent:
        log("Sincronizzati {0} avanzamenti dalla coda offline.".format(sent))
    return not pending


def get_remote_progress(identity):
    """Legge il punto di ripresa salvato per il contenuto corrente."""
    if not isinstance(identity, dict):
        return None
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    token = get_device_token(base_url) if base_url else ""
    if not base_url or not token:
        return None
    query = {
        "mediaType": identity.get("mediaType", ""),
        "tmdbId": identity.get("tmdbId", 0),
    }
    if identity.get("mediaType") == "episode":
        query.update({
            "season": identity.get("season", 0),
            "episode": identity.get("episode", 0),
        })
    request = urllib.request.Request(
        base_url + "/progress?" + urllib.parse.urlencode(query),
        headers={
            "Authorization": "Bearer " + token,
            "User-Agent": USER_AGENT,
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            data = json.loads(response.read().decode("utf-8"))
            _record_sync_result(True, "resume")
            progress = data.get("progress")
            return progress if isinstance(progress, dict) else None
    except urllib.error.HTTPError as error:
        log("Lettura ripresa: HTTP {0}".format(error.code), xbmc.LOGWARNING)
        _record_sync_result(False, "resume", "HTTP {0}".format(error.code))
    except (urllib.error.URLError, OSError, TypeError, ValueError) as error:
        log("Punto di ripresa non disponibile: {0}".format(error), xbmc.LOGWARNING)
        _record_sync_result(False, "resume", "Servizio non raggiungibile")
    return None


def get_sync_status():
    """Restituisce diagnostica locale senza esporre il token del dispositivo."""
    with _status_lock:
        saved = _read_status_file()
    return {
        "linked": bool(ADDON.getSettingString("access_token").strip()),
        "enabled": ADDON.getSettingBool("enabled"),
        "deviceName": get_device_name(),
        "pendingCount": len(_read_outbox()),
        "lastSuccessAt": saved.get("lastSuccessAt", ""),
        "lastAttemptAt": saved.get("lastAttemptAt", ""),
        "lastAction": saved.get("lastAction", ""),
        "lastError": saved.get("lastError", ""),
    }


def test_connection():
    """Verifica token e API con una lettura innocua del progresso."""
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    token = ADDON.getSettingString("access_token").strip()
    if not base_url or not token:
        _record_sync_result(False, "test", "Kodi non collegato")
        return False, "not_linked"
    query = urllib.parse.urlencode({"mediaType": "movie", "tmdbId": 1})
    request = urllib.request.Request(
        base_url + "/progress?" + query,
        headers={
            "Authorization": "Bearer " + token,
            "User-Agent": USER_AGENT,
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            success = 200 <= response.status < 300
            _record_sync_result(success, "test", "Risposta non valida" if not success else "")
            return success, "" if success else "invalid_response"
    except urllib.error.HTTPError as error:
        _record_sync_result(False, "test", "HTTP {0}".format(error.code))
        return False, "HTTP {0}".format(error.code)
    except (urllib.error.URLError, OSError, ValueError):
        _record_sync_result(False, "test", "Servizio non raggiungibile")
        return False, "unreachable"


def get_device_token(base_url):
    token = ADDON.getSettingString("access_token").strip()
    if token:
        return token
    code = ADDON.getSettingString("link_code").strip().upper()
    if not code or not base_url:
        return ""
    request = urllib.request.Request(
        base_url + "/session",
        data=json.dumps({"code": code, "deviceName": get_device_name()}).encode("utf-8"),
        headers={"Content-Type": "application/json", "User-Agent": USER_AGENT},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            data = json.loads(response.read().decode("utf-8"))
            token = data.get("token", "")
            if token:
                ADDON.setSettingString("access_token", token)
                ADDON.setSettingString("link_code", "")
                _record_sync_result(True, "link")
                log("Kodi collegato al profilo TECHAM Replay.")
                xbmcgui.Dialog().notification(
                    "TECHAM Replay",
                    "Kodi collegato al tuo profilo.",
                    time=5000,
                )
                return token
    except (urllib.error.HTTPError, urllib.error.URLError, OSError, ValueError) as error:
        log("Collegamento Kodi non riuscito: {0}".format(error), xbmc.LOGWARNING)
    return ""


def update_device_name(base_url, token):
    """Aggiorna il nome del dispositivo anche per i collegamenti esistenti."""
    request = urllib.request.Request(
        base_url + "/device",
        data=json.dumps({"deviceName": get_device_name()}).encode("utf-8"),
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
        },
        method="PUT",
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            return 200 <= response.status < 300
    except urllib.error.HTTPError as error:
        log("Aggiornamento nome dispositivo: HTTP {0}".format(error.code), xbmc.LOGWARNING)
    except (urllib.error.URLError, OSError, ValueError) as error:
        log("Nome dispositivo non aggiornato: {0}".format(error), xbmc.LOGWARNING)
    return False


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[TECHAM Replay Sync] " + message, level)
