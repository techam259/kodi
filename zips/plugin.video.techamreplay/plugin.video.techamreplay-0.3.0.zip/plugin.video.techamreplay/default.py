"""Pannello diagnostico di TECHAM Replay Sync per Kodi."""

import os
import sys
from datetime import datetime

import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))

from api import flush_pending_progress, get_sync_status, test_connection  # noqa: E402


TITLE = "TECHAM Replay Sync"


def text(identifier, fallback):
    value = ADDON.getLocalizedString(identifier)
    return value or fallback


def format_timestamp(value):
    if not value:
        return text(30020, "Mai")
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed.astimezone().strftime("%d/%m/%Y %H:%M")
    except (TypeError, ValueError):
        return str(value)


def status_message(status):
    linked = text(30014, "Collegato") if status["linked"] else text(30015, "Non collegato")
    enabled = text(30016, "Attiva") if status["enabled"] else text(30017, "Disattivata")
    lines = [
        "{0}: {1}".format(text(30026, "Dispositivo"), status["deviceName"]),
        "{0}: {1}".format(text(30001, "Connessione"), linked),
        "{0}: {1}".format(text(30027, "Sincronizzazione"), enabled),
        "{0}: {1}".format(text(30018, "Elementi in attesa"), status["pendingCount"]),
        "{0}: {1}".format(
            text(30019, "Ultima sincronizzazione riuscita"),
            format_timestamp(status["lastSuccessAt"]),
        ),
    ]
    if status.get("lastError"):
        lines.append("{0}: {1}".format(text(30028, "Ultimo errore"), status["lastError"]))
    if not status["linked"]:
        lines.append("")
        lines.append(text(30025, "Collega Kodi dal profilo TECHAM Replay"))
    return "\n".join(lines)


def show_status():
    xbmcgui.Dialog().ok(TITLE, status_message(get_sync_status()))


def run():
    actions = [
        text(30010, "Stato sincronizzazione"),
        text(30011, "Verifica connessione"),
        text(30012, "Invia ora gli elementi in attesa"),
        text(30013, "Apri impostazioni"),
    ]
    while True:
        choice = xbmcgui.Dialog().select(TITLE, actions)
        if choice < 0:
            return
        if choice == 0:
            show_status()
        elif choice == 1:
            success, reason = test_connection()
            if success:
                xbmcgui.Dialog().ok(TITLE, text(30021, "Connessione riuscita"))
            elif reason == "not_linked":
                xbmcgui.Dialog().ok(TITLE, text(30025, "Collega Kodi dal profilo TECHAM Replay"))
            else:
                xbmcgui.Dialog().ok(
                    TITLE,
                    "{0}: {1}".format(text(30022, "Connessione non riuscita"), reason),
                )
        elif choice == 2:
            success = flush_pending_progress()
            message = text(30023, "Coda in attesa inviata") if success else text(
                30024,
                "Alcuni elementi sono ancora in attesa",
            )
            xbmcgui.Dialog().ok(TITLE, message)
        elif choice == 3:
            ADDON.openSettings()


if __name__ == "__main__":
    run()
