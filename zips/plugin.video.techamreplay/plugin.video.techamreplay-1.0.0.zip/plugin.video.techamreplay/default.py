"""Pannello diagnostico di TECHAM Replay Sync per Kodi."""

import os
import sys
from datetime import datetime

import xbmcaddon
import xbmcgui


ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))

from api import (  # noqa: E402
    connect_with_code,
    disconnect_device,
    flush_pending_progress,
    get_sync_status,
    test_connection,
)


TITLE = "TECHAM Replay Sync"


def text(identifier, fallback):
    value = ADDON.getLocalizedString(identifier)
    return value or fallback


def format_timestamp(value):
    if not value:
        return text(30020, "Mai")
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed.astimezone().strftime("%d/%m/%Y %H:%M")
    except (TypeError, ValueError):
        return str(value)


def status_message(status):
    linked = text(30014, "Collegato") if status["linked"] else text(30015, "Non collegato")
    enabled = text(30016, "Attiva") if status["enabled"] else text(30017, "Disattivata")
    api_state = text(30052, "Valido") if status["apiConfigured"] else text(30053, "Non valido")
    action_labels = {
        "progress": text(30044, "Invio avanzamento"),
        "resume": text(30045, "Lettura punto di ripresa"),
        "test": text(30046, "Verifica connessione"),
        "link": text(30047, "Collegamento dispositivo"),
        "disconnect": text(30048, "Disconnessione dispositivo"),
        "device": text(30049, "Aggiornamento dispositivo"),
    }
    lines = [
        "{0}: {1}".format(text(30029, "Versione"), status["version"]),
        "{0}: {1}".format(text(30026, "Dispositivo"), status["deviceName"]),
        "{0}: {1}".format(text(30001, "Connessione"), linked),
        "{0}: {1}".format(text(30051, "Indirizzo API"), api_state),
        "{0}: {1}".format(text(30027, "Sincronizzazione"), enabled),
        "{0}: {1}".format(text(30018, "Elementi in attesa"), status["pendingCount"]),
        "{0}: {1}".format(
            text(30019, "Ultima sincronizzazione riuscita"),
            format_timestamp(status["lastSuccessAt"]),
        ),
        "{0}: {1}".format(
            text(30030, "Ultimo tentativo"),
            format_timestamp(status["lastAttemptAt"]),
        ),
    ]
    if status.get("lastAction"):
        lines.append("{0}: {1}".format(
            text(30031, "Ultima operazione"),
            action_labels.get(status["lastAction"], status["lastAction"]),
        ))
    if status.get("lastError"):
        lines.append("{0}: {1}".format(text(30028, "Ultimo errore"), status["lastError"]))
    if not status["linked"]:
        lines.append("")
        lines.append(text(30025, "Collega Kodi dal profilo TECHAM Replay"))
    return "\n".join(lines)


def show_status():
    xbmcgui.Dialog().ok(TITLE, status_message(get_sync_status()))


def run():
    while True:
        status = get_sync_status()
        actions = [(text(30010, "Stato sincronizzazione"), "status")]
        if status["linked"]:
            actions.append((text(30011, "Verifica connessione"), "test"))
        else:
            actions.append((text(30032, "Collega Kodi"), "link"))
        actions.extend([
            (text(30054, "Novità della versione"), "news"),
            (text(30012, "Invia ora gli elementi in attesa"), "flush"),
            (text(30013, "Apri impostazioni"), "settings"),
        ])
        if status["linked"]:
            actions.append((text(30037, "Disconnetti Kodi"), "disconnect"))
        choice = xbmcgui.Dialog().select(TITLE, [label for label, _ in actions])
        if choice < 0:
            return
        action = actions[choice][1]
        if action == "status":
            show_status()
        elif action == "link":
            code = xbmcgui.Dialog().input(
                text(30033, "Inserisci il codice Kodi di 10 caratteri"),
                type=xbmcgui.INPUT_ALPHANUM,
            )
            if not code:
                continue
            success, reason = connect_with_code(code)
            if success:
                xbmcgui.Dialog().ok(TITLE, text(30036, "Kodi collegato correttamente"))
            elif reason == "invalid_code":
                xbmcgui.Dialog().ok(TITLE, text(30034, "Il codice inserito non è valido"))
            elif reason == "invalid_url":
                xbmcgui.Dialog().ok(TITLE, text(30042, "L'indirizzo API non è valido"))
            else:
                xbmcgui.Dialog().ok(TITLE, text(30035, "Collegamento non riuscito: genera un nuovo codice"))
        elif action == "test":
            success, reason = test_connection()
            if success:
                xbmcgui.Dialog().ok(TITLE, text(30021, "Connessione riuscita"))
            elif reason == "not_linked":
                xbmcgui.Dialog().ok(TITLE, text(30025, "Collega Kodi dal profilo TECHAM Replay"))
            else:
                xbmcgui.Dialog().ok(
                    TITLE,
                    "{0}: {1}".format(text(30022, "Connessione non riuscita"), reason),
                )
        elif action == "news":
            xbmcgui.Dialog().ok(
                TITLE,
                text(
                    30055,
                    "Versione 1.0: collegamento e disconnessione dal pannello, "
                    "diagnostica completa, coda offline protetta e supporto agli episodi speciali.",
                ),
            )
        elif action == "flush":
            success = flush_pending_progress()
            message = text(30023, "Coda in attesa inviata") if success else text(
                30024,
                "Alcuni elementi sono ancora in attesa",
            )
            xbmcgui.Dialog().ok(TITLE, message)
        elif action == "settings":
            ADDON.openSettings()
        elif action == "disconnect":
            if not xbmcgui.Dialog().yesno(
                TITLE,
                text(30038, "Disconnettere questo Kodi dal profilo TECHAM Replay?"),
            ):
                continue
            success, reason = disconnect_device()
            if success:
                xbmcgui.Dialog().ok(TITLE, text(30039, "Kodi disconnesso"))
                continue
            force_local = xbmcgui.Dialog().yesno(
                TITLE,
                text(30040, "Il server non è raggiungibile."),
                text(30041, "Disconnettere soltanto questo Kodi? La coda sarà conservata."),
            )
            if force_local:
                disconnect_device(force_local=True)
                xbmcgui.Dialog().ok(TITLE, text(30039, "Kodi disconnesso"))


if __name__ == "__main__":
    run()
