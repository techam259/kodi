"""Servizio Kodi: osserva i film e gli episodi terminati nella libreria locale."""

import json
import os
import sys
import time

import xbmc
import xbmcaddon

ADDON_PATH = xbmcaddon.Addon().getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))

from api import get_device_token, log, sync_progress  # noqa: E402


ADDON = xbmcaddon.Addon()


class ReplayMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        if method != "Player.OnStop" or not ADDON.getSettingBool("enabled"):
            return

        try:
            notification = json.loads(data)
            item = notification.get("item", {})
            media_type = item.get("type")
            library_id = item.get("id")
            end = notification.get("end", False)
            if media_type not in ("movie", "episode") or not library_id or not end:
                return
            self._sync_library_item(media_type, library_id)
        except (TypeError, ValueError, KeyError) as error:
            log("Evento Kodi non leggibile: {0}".format(error), xbmc.LOGWARNING)

    def _sync_library_item(self, media_type, library_id):
        method = "VideoLibrary.GetMovieDetails" if media_type == "movie" else "VideoLibrary.GetEpisodeDetails"
        key = "moviedetails" if media_type == "movie" else "episodedetails"
        result = json_rpc(method, {
            "movieid" if media_type == "movie" else "episodeid": library_id,
            "properties": ["uniqueid", "playcount", "season", "episode", "showtitle", "title"],
        })
        details = result.get(key, {})
        if not details.get("playcount", 0):
            return

        unique_ids = details.get("uniqueid", {})
        tmdb_id = unique_ids.get("tmdb")
        if not tmdb_id:
            log("Contenuto ignorato: manca l'identificativo TMDb in Kodi.", xbmc.LOGDEBUG)
            return

        payload = {
            "mediaType": media_type,
            "tmdbId": int(tmdb_id),
            "watched": True,
        }
        if media_type == "episode":
            payload.update({
                "season": int(details.get("season", 0)),
                "episode": int(details.get("episode", 0)),
                "seriesTitle": details.get("showtitle", ""),
            })
        else:
            payload["title"] = details.get("title", "")
        sync_progress(payload)


def json_rpc(method, params):
    query = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
    response = xbmc.executeJSONRPC(query)
    parsed = json.loads(response)
    return parsed.get("result", {})


def link_device_if_needed():
    """Scambia il codice appena viene salvato nelle impostazioni."""
    if ADDON.getSettingString("access_token").strip():
        return
    if not ADDON.getSettingString("link_code").strip():
        return
    base_url = ADDON.getSettingString("api_url").rstrip("/")
    if base_url:
        get_device_token(base_url)


if __name__ == "__main__":
    monitor = ReplayMonitor()
    log("Servizio avviato.")
    next_link_attempt = 0.0
    while not monitor.abortRequested():
        now = time.monotonic()
        if now >= next_link_attempt:
            link_device_if_needed()
            next_link_attempt = now + 15.0
        if monitor.waitForAbort(1):
            break
